runBiodiff <- function(	dataset,
						design=NULL,
						class1=NULL,
						class2=NULL,
						normalize=NULL,
						diff.type="log2FC",
						test.type="t",
						rowSumCutoff=NULL, # alternatively, we could put 1 as the default value
						increment=0.1,
						adj.method="BH",
						ARC.denominator="max",
						verbose=T
					){
  if(class(dataset) %in% c("eSet","ExpressionSet")){
    if(is.null(design))	design <- pData(dataset)
	dataset <- exprs(dataset)
  }
  if( !(class(dataset[,1]) %in% c("numeric","integer")) )	stop("The first column of your dataset does not appear to be numeric. If it contains the feature names, please put them as row names.")
  diff.type <- match.arg(diff.type, c("ARC","FC","log2FC","absolute"))
  ARC.denominator <- match.arg(ARC.denominator, c("min","max","mean","class1"))
  if(verbose){
	  if(diff.type=="ARC"){
		if(ARC.denominator=="class1"){
			message("Using average relative change (ARC) as a measure of difference, with ARC=(class2-class1)/class1")
		}else{
			message("Using average relative change (ARC) as a measure of difference, with ARC=(class2-class1)/",ARC.denominator,"(class1,class2)")
		}
	  }else{
		message("You are using ",diff.type," as a measure of difference")
	  }
  }
  if(!(test.type %in% c("t"))) stop("Unknown value for parameter test.type.")
  if(!is.data.frame(design) | !("background" %in% names(design)) | !("testCondition" %in% names(design))) stop("Malformed design dataframe.")
  if(is.null(class1))	class1 <- design$testCondition[1]
  if(!(class1 %in% design$testCondition)) stop("Unknown class1.")  
  if(is.null(class2))	class2 <- design$testCondition[which(design$testCondition != class1)][1]
  if(!(class2 %in% design$testCondition)) stop("Unknown class2.")  
  if(verbose)	message("Comparing class '",class2,"' against class '",class1,"'")
  
  if(is.null(normalize)){
	message("Warning: no normalization parameter was given, and we are therefore assuming that the count data has been already normalized.")
  }else{
	if(normalize != "none"){
		normalize <- match.arg(normalize, c("TMM","RLE","upperquartile"))
		if(verbose) message("Normalizing data using the ",normalize," method.")
		dataset <- donorm(dataset, normalize)
	}
  }
  
  dataset <- dataset+increment 
	
  # -------- input processed; now start the algorithm

  backgrounds <- unique(as.character(design$background))
  if(sum(duplicated(apply(design[,c("background","testCondition")],1,collapse=" ",FUN=paste)))){
    if(verbose) message("Using procedure for complex pairings.")
    dfout <- as.data.frame(t(apply(dataset,1,FUN=function(x){
	  diffvalues <- c()
	  sds <- c()
	  for(p in unique(design$background)){
	    cl1 <- mean(x[design$background==p & design$testCondition==class1])
	    cl2 <- mean(x[design$background==p & design$testCondition==class2])
	    adiff <- getClassDifference(mean(cl1),mean(cl2),diff.type,ARC.denominator)
	    diffvalues = c(diffvalues,adiff)
	    sds <- c(sds, getClassDiffSD(cl1,cl2,diff.type,ARC.denominator))
	  }
	  diffsd <- sqrt(sum(sds^2)*1/length(sds)^2)
	  if(diffsd==0)	diffsd <- sd(diffvalues)
	  pvalue = getClassTest(diffvalues, diffsd, test.type)
	  return(c(diffvalues,mean(diffvalues),pvalue))		
    })))
    row.names(dfout) <- row.names(dataset)
    i <- 1
    for(p in backgrounds){
      names(dfout)[i] <- paste(diff.type,p,sep=".")
      i <- i+1
    }
    names(dfout)[i] <- paste("mean",diff.type,sep="")
    names(dfout)[i+1] <- "p.value"
    dfout <- dfout[dfout[,i]>0,]    
  }else{
    if(verbose) message("Using procedure for simple pairings.")
    dfout <- data.frame(row.names=row.names(dataset))
    for(p in backgrounds){
      cl1 <- dataset[,design$background==p & design$testCondition==class1]
      cl2 <- dataset[,design$background==p & design$testCondition==class2]
      if(diff.type=="ARC"){
		if(ARC.denominator == "class1")	dfout[,paste("ARC",p,sep=".")] <- (cl2-cl1)/cl1
		else if(ARC.denominator == "max") dfout[,paste("ARC",p,sep=".")] <- (cl2-cl1)/as.numeric(apply(cbind(cl1,cl2),1,FUN=max))
		else if(ARC.denominator == "min") dfout[,paste("ARC",p,sep=".")] <- (cl2-cl1)/as.numeric(apply(cbind(cl1,cl2),1,FUN=min))
        else dfout[,paste("ARC",p,sep=".")] <- 2*(cl2-cl1)/(cl1+cl2)
      }else{
        if(diff.type=="FC") dfout[,paste("FC",p,sep=".")] <- cl2/cl1
        else if(diff.type=="log2FC") dfout[,paste("log2FC",p,sep=".")] <- log2(cl2/cl1)
        else dfout[,paste("diff",p,sep=".")] <- cl2-cl1
      }
    }
    means <- apply(dfout[,1:length(backgrounds)],1,FUN=mean)
    dfout[,paste("mean",diff.type,sep="")] <- means
    dfout$p.value <- apply(dfout[,1:length(backgrounds)],1,test.type=test.type,FUN=getClassTest)
  }
  
  dfout$p.adjust <- p.adjust(dfout$p.value,method=adj.method)
  return(dfout)
}

# Reads a cuffdiff read_group_tracking file into a count matrix 


readCuffdiff <- function( path,				# path to cuffdiff read_group_tracking file (e.g. genes.read_group_tracking)
						  fetch="raw",		# what value to fetch: either "raw", "normalized" or "fpkm"
						  samples.names=NA,	# manual input of the sample names, in the order in which they appear in the read_group_tracking file
						  ok.only=T,		# whether or not to take only the genes marked by cuffdiff as OK in all samples
						  verbose=T ){		# whether to output info on progress
	if(!file.exists(path)) stop(paste("Could not find file",path))
	fetch <- match.arg(fetch, c("raw","normalized","fpkm"))
	cols <- switch(fetch,
		raw = c(1:3,4),
		normalized = c(1:3,6),
		fpkm = c(1:3,7),
		stop("Unknown value for parameter fetch.")
	)
	if(verbose)	message("Loading file...")
	g <- read.delim(path,header=T,stringsAsFactors=F)
	if(!identical(names(g),c("tracking_id","condition","replicate","raw_frags","internal_scaled_frags","external_scaled_frags","FPKM","effective_length","status"))){
		stop("The column names of the file do not match the expected cuffdiff output. Is this a read_group_tracking file?")
	}
	if(ok.only){
		discarded <- unique(g$tracking_id[which(g$status!="OK")])
		if(verbose)	message(paste("Removing",length(discarded), "genes or features because of status != OK."))
		g <- g[which( !(g$tracking_id %in% discarded) ),]
	}
	g <- g[,cols]
	if(verbose)	message("Identifying rows...")
	g$concat <- apply(g[,2:3],1,collapse="",sep="",FUN=paste)
	s <- unique(g$concat)
	if( is.character(samples.names) ){
		if( length(samples.names) != length(s) ){
			warning(paste("sample.names has a length of",length(samples.names),", while the dataset counts",length(s),"samples. sample.names will not be used."))
			samples.names <- NA
		}
	}else{
		samples.names <- NA
	}
	if(is.na(samples.names))	samples.names <- s
	if(verbose)	message("Assembling count matrix...")
	out <- as.data.frame(matrix(g[order(g$concat,g$tracking_id),4], ncol=length(s)))
	genes <- unique(g$tracking_id)
	row.names(out) <- genes[order(genes)]
	names(out) <- samples.names[order(s)]
	return(out)
}

donorm <- function( dataset, method="TMM" ){
	library(edgeR)
	d <- DGEList(counts=dataset,group=names(dataset))
	d <- calcNormFactors(d, method=method)
	cnts <- cpm(d, normalized.lib.sizes=T)*mean(d$samples$lib.size)/1000000
	return(cnts)
}

# Computes class difference using the desired method
getClassDifference <- function(cl1,cl2,diff.type="ARC",ARC.denominator="mean"){
  if(!is.numeric(cl1) | !is.numeric(cl2)) return(NA)
  if(diff.type=="ARC"){
	if(ARC.denominator == "max")	return( (cl2-cl1)/max(cl1,cl2) )
	if(ARC.denominator == "min")	return( (cl2-cl1)/min(cl1,cl2) )
	if(ARC.denominator == "class1")	return( (cl1-cl1)/cl1 )
	return(2*(cl2-cl1)/(cl1+cl2))
  }
  if(diff.type=="FC")	return(cl2/cl1)
  if(diff.type=="log2FC")	return(log2(cl2/cl1))
  if(diff.type=="absolute")	return(cl2-cl1)
  return(NA)
}

# For complex designs, computes the standard deviation of the class difference,
# approximating a propagation of the uncertainty
getClassDiffSD <- function(cl1,cl2,diff.type,ARC.denominator="mean"){
  if(!is.numeric(cl1) | !is.numeric(cl2)) return(NA)
  sd1 <- sd(cl1)
  sd2 <- sd(cl2)
  if(is.na(sd1))	sd1 <- 0
  if(is.na(sd2))	sd2 <- 0
  if( (sd1+sd2)==0 ) return(0)
  cl1 <- mean(cl1)
  cl2 <- mean(cl2)
  if(diff.type=="ARC"){
    if(ARC.denominator == "max"){
		denom <- max(cl1,cl2)
		denomsd <- c(sd1,sd2)[order(c(cl1,cl2), decreasing=T)[1]]
	}else if(ARC.denominator == "min"){
		denom <- min(cl1,cl2)
		denomsd <- c(sd1,sd2)[order(c(cl1,cl2))[1]]
	}else if(ARC.denominator == "class1"){
		denom <- cl1
		denomsd <- sd1	
	}else{
		denom <- mean(c(cl1,cl2))
		denomsd <- sqrt( (sd1^2+sd2^2)/4 )
	}
	thediff <- (cl2-cl1)/denom
    return(thediff*sqrt((sqrt(sd1^2+sd2^2)/(cl2-cl1))^2+(denomsd/denom)^2))
  }
  if(diff.type=="FC")    return(cl2/cl1*sqrt((sd2/cl2)^2+(sd1/cl1)^2))
  if(diff.type=="log2FC")    return(sqrt((sd2/cl2)^2+(sd1/cl1)^2)/ln(2))
  if(diff.type=="absolute")	return(sqrt(sd1^2+sd2^2))
  return(NA)
}

# Tests the class differences for significance
getClassTest <- function(x,dsd=F,test.type="t"){
  if( (sum(x, na.rm=T)==0) )	return(NA)
  if(test.type=="t"){
    dsd2 <- sd(x, na.rm=T)
    if(is.na(dsd2))	dsd2 <- 0
    if(is.na(dsd))	dsd <- 0
    if(dsd==FALSE)	dsd <- 0
    if(dsd == 0 & dsd2 == 0)	return(NA)
    if(all(is.numeric(dsd)) & dsd>dsd2 ){
      # using input standard deviation
      t <- mean(x)/(dsd/sqrt(length(x)))
      return(2*pt(t,df=length(x)-1,lower.tail=F))
    }else{
      if( is.na(dsd2) | dsd2==0 )	return(0)
      return(t.test(x)$p.value)
    }
  }
  # other tests to be implemented
  stop("not implemented")
}

getSignsTable <- function(dataset, design, class1=NULL, class2=NULL, verbose=T){
	if(!is.data.frame(design) | !("background" %in% names(design)) | !("testCondition" %in% names(design))) stop("Malformed design dataframe.")
	if(!("platform" %in% names(design))){
		if(verbose)	message("Platform is undefined in the design table. Assuming common platform.")
		design$platform <- 1
	}
	if(class(dataset) %in% c("eSet","ExpressionSet")){
		if(is.null(design))	design <- pData(dataset)
		dataset <- exprs(dataset)
	}
	if( !(class(dataset[,1]) %in% c("numeric","integer")) )	stop("The first column of your dataset does not appear to be numeric. If it contains the feature names, please put them as row names.")
	if(is.null(class1) | is.null(class2)){
		if(is.null(class1))	class1 <- design$testCondition[1]
		if(is.null(class2))	class2 <- design$testCondition[which(design$testCondition != class1)][1]
		if(verbose)	message("Comparing class '",class2,"' against class '",class1,"'")		
	}
	if(!(class1 %in% design$testCondition)) stop("Unknown class1.")  
	if(!(class2 %in% design$testCondition)) stop("Unknown class2.")  
	mat <- sign(dataset[,design$testCondition==class2] - dataset[,design$testCondition==class1])
	mat <- mat[apply(mat,1,FUN=function(x){ any(!is.na(x))}),]
	names(mat) <- paste(design$platform[design$testCondition==class2],design$background[design$testCondition==class2],sep=".")
	return(mat)
}

runBinomTest <- function(dataset, design, class1=NULL, class2=NULL, rowSumCutoff=0, normalize=NULL, adjust.probabilities=T, adj.method="BH", summary.method="median", verbose=T){
	if(!is.data.frame(design) | !("background" %in% names(design)) | !("testCondition" %in% names(design))) stop("Malformed design dataframe.")
	if(!("platform" %in% names(design))){
		if(verbose)	message("Platform is undefined in the design table. Assuming common platform.")
		design$platform <- 1
	}	
	summary.method <- match.arg(summary.method, c("median","mean"), several.ok=T)
	if(is.null(class1) | is.null(class2)){
		if(is.null(class1))	class1 <- design$testCondition[1]
		if(is.null(class2))	class2 <- design$testCondition[which(design$testCondition != class1)][1]
		if(verbose)	message("Comparing class '",class2,"' against class '",class1,"'")		
	}
	if(!(class1 %in% design$testCondition)) stop("Unknown class1.")  
	if(!(class2 %in% design$testCondition)) stop("Unknown class2.")  
	if(is.null(rowSumCutoff)){
		rowSumCutoff = 10*ncol(dataset)
	}else{ 
		if(!is.numeric(rowSumCutoff) | length(rowSumCutoff) > 1)	stop("Invalid rowSumCutoff.")
	}
	aboveCutoff <- rowSums(dataset,na.rm=T)>rowSumCutoff	
	if(rowSumCutoff > 0 & verbose) message("Removing ",nrow(dataset)-sum(aboveCutoff)," rows with ",rowSumCutoff," reads or less")
	dataset <- dataset[aboveCutoff,]
	o <- order(design$platform, design$testCondition, design$background)
	dataset <- dataset[,o]
	design <- design[o,]	
	if(is.null(normalize)){
		message("Warning: no normalization parameter was given, and we are therefore assuming that the count data has been already normalized.")
	}else{
		if(normalize != "none"){
			normalize <- match.arg(normalize, c("TMM","RLE","upperquartile"))
			if(verbose) message("Normalizing data using the ",normalize," method.")
			for( p in unique(design$platform) ){
				if(	design$background[design$platform==p & design$testCondition==class1] !=
					design$background[design$platform==p & design$testCondition==class2] ){
					stop("The data for platform ",p," are not properly paired. Remove any mismatched samples.")
				}
				dataset[,design$platform==p] <- donorm(dataset[,design$platform==p], normalize)
			}
		}
	}
	fcs <- (0.1+dataset[,design$testCondition==class2]) / (0.1+dataset[,design$testCondition==class1])
	mat <- getSignsTable(dataset, design, class1, class2)
	dfout <- data.frame(row.names=row.names(mat))
	dfout$up <- apply(mat,1,FUN=function(x){ sum(x>0,na.rm=T)})
	dfout$down <- apply(mat,1,FUN=function(x){ sum(x<0,na.rm=T)})
	for(p in unique(design$platform)){
	  for(s in summary.method){
		dfout[,paste(p,s,"expression",sep=".")] <- apply(dataset[,which(design$platform==p)],1,na.rm=T,FUN=s)
		dfout[,paste(p,s,"foldchange",sep=".")] <- apply(fcs[,which(design$platform[design$testCondition==class1]==p)],1,na.rm=T,FUN=s)
	  }
	}
	if(adjust.probabilities){
		p <- sum(mat>0,na.rm=T)/sum(!is.na(mat))
	}else{
		p <- 0.5
	}	
	dfout$pval.nbinom <- apply(dfout,1,FUN=function(x){
		n <- x[1]+x[2]
		if(n==0)	return(NA)
		binom.test(x[1],x[1]+x[2],p)$p.value
	})
	dfout <- dfout[!is.na(dfout$pval.nbinom),]
	dfout$FDR <- p.adjust(dfout$pval.nbinom, method=adj.method)
	dfout[order(dfout$FDR),]
}


findSignature <- function(signsTable, groups, method="fisher"){
	if(length(groups) != ncol(signsTable))	stop("The groups vector length is different from the number of columns in the signs matrix.")
	if(length(unique(groups)))	warning("The groups vector contains more than two possible values. Positive values will be conflated upon transformation to logical values.")
	groups <- as.logical(groups)
	if(length(unique(groups))==1)	stop("Only one group!")
	method <- match.arg(method, c("fisher","binom"), several.ok=T)
	signsTable <- signsTable[apply(signsTable,1,FUN=function(x){ any(!is.na(x))}),]
	dfout <- data.frame(row.names=row.names(signsTable))
	dfout$oddsRatio <- apply(signsTable,1,FUN=function(x){ (sum(x[groups]>0, na.rm=T)/sum(!is.na(x[groups])))/(sum(x[!groups]>0, na.rm=T)/sum(!is.na(x[!groups])))  })
	if("binom" %in% method){
		dfout$pval.binom <- apply(signsTable,1,FUN=function(x){
			p <- (sum(x>0, na.rm=T)/sum(!is.na(x)))			
			binom.test(sum(x[groups]>0, na.rm=T),sum(!is.na(x[groups])),p)$p.value
		})
		dfout$fdr.binom <- p.adjust(dfout$pval.binom, method="fdr")
	}
	if("fisher" %in% method){
		dfout$pval.fisher <- apply(signsTable,1,FUN=function(x){
			m <- matrix( c(sum(x[groups]>0, na.rm=T), sum(!(x[groups]>0), na.rm=T),
							sum(x[!groups]>0, na.rm=T), sum(!(x[!groups]>0), na.rm=T)),
							nrow = 2,
							dimnames = list(InGroup = c("Up", "Down"),
											OutGroup = c("Up", "Down"))
						)
			fisher.test(m)$p.value
		})
		dfout$fdr.fisher <- p.adjust(dfout$pval.fisher, method="fdr")
	}
	dfout[order(dfout[,ncol(dfout)]),]
}
